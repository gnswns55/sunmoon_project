<?php
    //1.url를 변수에 담고 요청인수를 queryParams에 추가     <여객편 운항현황(다국어)_도착>
    // $no = $_GET["data"];
    // $ch = curl_init(); // 파싱 대상을 담을 변수 초기화
    // $AirportCode = 'getPassengerDepartures';/*공항 코드 정보*/    #getPassengerDepartures (원래)
    // $en_key = "bRRPPQsIvHTI8ETbQnK63XSCZQSoUoDRkU9UB8kNELgGxxLUpCrhlye7zwPv3F8dWPOVlh0ep0u%2B4QusndbPpg%3D%3D"; //서비스키 바꾸는 곳
    // $url = "http://openapi.airport.kr/openapi/service/StatusOfPassengerFlights/$AirportCode";
    //         #http://openapi.airport.kr/openapi/service/StatusOfPassengerFlights/getPassengerArrivals  #예비번호 (getPassengerArrivals)

    // $queryParams = '?' . urlencode('ServiceKey') . "=$en_key"; /*Service Key*/
    // $queryParams .= '&' . urlencode('to_time') . '=' .urlencode('2400');
    // $queryParams .= '&' . urlencode('airline') . '=' .urlencode('KE');
    // $queryParams .= '&' . urlencode('lang') . '=' .urlencode('E');
    // $queryParams .= '&' . urlencode('from_time') . '=' .urlencode('0000');
    // $queryParams .= '&' . urlencode('numOfRows') . '=' .urlencode('5');
    // $queryParams .= '&' . urlencode('pageNo') . '=' . urlencode($no); /*요청인수*/

    $no = $_GET["data"];
    $ch = curl_init(); // 파싱 대상을 담을 변수 초기화
    $AirportCode = 'getPassengerDeparturesW';/*공항 코드 정보*/    #getPassengerDepartures (원래)
    $en_key = "bRRPPQsIvHTI8ETbQnK63XSCZQSoUoDRkU9UB8kNELgGxxLUpCrhlye7zwPv3F8dWPOVlh0ep0u%2B4QusndbPpg%3D%3D";
    $url = "http://openapi.airport.kr/openapi/service/StatusOfPassengerWeahter/$AirportCode";
            #http://openapi.airport.kr/openapi/service/StatusOfPassengerFlights/getPassengerArrivals    #예비번호 (getPassengerArrivals)

    $queryParams = '?' . urlencode('ServiceKey') . "=$en_key"; /*Service Key*/
    $queryParams .= '&' . urlencode('to_time') . '=' .urlencode('2400');
    $queryParams .= '&' . urlencode('airline') . '=' .urlencode('KE');
    $queryParams .= '&' . urlencode('lang') . '=' .urlencode('E');
    $queryParams .= '&' . urlencode('from_time') . '=' .urlencode('0000');
    $queryParams .= '&' . urlencode('numOfRows') . '=' .urlencode('10');
    $queryParams .= '&' . urlencode('pageNo') . '=' . urlencode($no); /*요청인수*/

    curl_setopt($ch, CURLOPT_URL, $url .$queryParams); // 파싱대상설정
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);  // 파싱 결과  string 형식으로 변환
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $response = curl_exec($ch);  // 실행결과 담김
    curl_close($ch);
    print_r($response);
?>


<!-- http://openapi.airport.kr/openapi/service/StatusOfPassengerFlights/getPassengerDepartures -->

